# frozen_string_literal: false
class Gem::Commands::CrashCommand < Gem::Command

  raise "crash"

end
