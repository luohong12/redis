# frozen_string_literal: false
class TestGem
  TEST_PLUGIN_LOAD = :loaded
end
